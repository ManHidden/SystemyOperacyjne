//
// Created by patryk on 09.04.18.
//

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <wait.h>

int main(int argc, char* argv[]){

    if (argc != 3){
        printf("Nie podano odpowiedniej liczby argumentów\n");
        exit(2);
    }

    int i;
    for(int i = 1; i < 4; i++){

        switch(fork()){
            case -1:
                perror("Fork error");
                break;
            case 0:
                execl("obsluguj", "obsluguj.c", argv[1], argv[2], (char *)0);
                break;
            default:
                sleep(2);
                signal(atoi(argv[1]), SIG_IGN);
                break;
        }
    }

    killpg(getpid(), atoi(argv[1]));
    int ii;

    for (ii = 1; ii < 4; ii++){
        wait(NULL);
    }

    raise(9);

}